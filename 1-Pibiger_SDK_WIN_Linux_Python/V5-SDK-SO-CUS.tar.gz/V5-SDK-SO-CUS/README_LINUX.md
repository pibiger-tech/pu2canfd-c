# USB-CAN SDK — Linux Customer Package

Pre-built shared libraries and Qt6 GUI for PCAN and gs_usb / candleLight CAN
adapters. Built against Ubuntu 22.04 (glibc 2.35) — forward-compatible with
newer Ubuntu / Debian distributions.

## Package layout

```
V5-SDK-SO-CUS/
├── README_LINUX.md           this file
├── ubuntu22.04-x64/           Intel / AMD 64-bit
│   ├── lib/libusb_can.so      + SONAME symlinks (.so.5, .so.5.0.0)
│   ├── bin/canviewer          Qt6 GUI
│   ├── bin/can_example        CLI quick-start
│   ├── include/can/*.h        public API
│   ├── examples/basic_can.c   sample source
│   └── run_viewer.sh          GUI launcher (sets LD_LIBRARY_PATH)
└── ubuntu22.04-arm64/         Raspberry Pi / Jetson / ARM SBCs (same layout)
```

## System requirements

- Ubuntu 22.04 LTS or newer (Debian 12+, Raspberry Pi OS Bookworm)
- libusb 1.0 runtime
- Qt6 runtime (only required for the `canviewer` GUI)

```bash
sudo apt update
sudo apt install -y libusb-1.0-0 libqt6widgets6 libqt6gui6 libqt6core6
```

## Linux back-ends

| Device                          | Back-end the SDK uses           | Driver needed                    |
|---------------------------------|---------------------------------|----------------------------------|
| PCAN-USB / PCAN-USB FD          | SocketCAN (kernel `peak_usb`)   | None — already in mainline kernel |
| candleLight / CANable / gs_usb  | SocketCAN (kernel `gs_usb`)     | None — already in mainline kernel |

Bring up an interface before running the SDK:

```bash
sudo ip link set can0 up type can bitrate 500000
# CAN FD:
sudo ip link set can0 up type can bitrate 500000 dbitrate 2000000 fd on
```

## Run the GUI

```bash
# x86_64 desktop
cd ubuntu22.04-x64 && ./run_viewer.sh

# arm64 (Raspberry Pi / Jetson)
cd ubuntu22.04-arm64 && ./run_viewer.sh
```

`run_viewer.sh` sets `LD_LIBRARY_PATH` so the GUI finds the SDK shared library
next to itself.

## Build and link your own application

```c
// my_app.c
#include <can/usb_can_sdk.h>
#include <stdio.h>

int main(void) {
    can_sdk_init();
    can_device_info_t devs[CAN_MAX_DEVICES];
    int n = can_discover(devs, CAN_MAX_DEVICES);
    printf("Found %d CAN device(s)\n", n);
    can_sdk_shutdown();
    return 0;
}
```

```bash
ARCH_DIR=ubuntu22.04-x64       # or ubuntu22.04-arm64
gcc my_app.c \
    -I$ARCH_DIR/include \
    -L$ARCH_DIR/lib -lusb_can \
    -Wl,-rpath,'$ORIGIN/lib' \
    -o my_app
```

`-Wl,-rpath,'$ORIGIN/lib'` lets the resulting binary find `libusb_can.so`
next to itself, so you can ship `my_app` + `lib/` together without
polluting `/usr/lib`.

## Public API headers (`include/can/`)

| Header             | Contents                                        |
|--------------------|-------------------------------------------------|
| `usb_can_sdk.h`    | Single-include entry point                      |
| `can_types.h`      | Types, flags, status codes, message struct      |
| `can_device.h`     | All device-control API declarations             |

## Verify the package

```bash
file ubuntu22.04-x64/lib/libusb_can.so.5.0.0
# ELF 64-bit LSB shared object, x86-64, dynamically linked, ...

file ubuntu22.04-arm64/lib/libusb_can.so.5.0.0
# ELF 64-bit LSB shared object, ARM aarch64, dynamically linked, ...

nm -D --defined-only ubuntu22.04-x64/lib/libusb_can.so | wc -l
# Several dozen exported symbols
```

## Troubleshooting

| Symptom                                       | Fix                                                                 |
|-----------------------------------------------|----------------------------------------------------------------------|
| `Permission denied` opening device            | Run `sudo ip link set can0 up ...` (or appropriate udev rule)        |
| `error while loading shared libraries: libQt6Widgets.so.6` | `sudo apt install libqt6widgets6 libqt6gui6 libqt6core6`     |
| `error while loading shared libraries: libusb_can.so` | Use `run_viewer.sh`, or set `LD_LIBRARY_PATH=lib`                    |
| `version 'GLIBC_2.34' not found`              | Distro is older than Ubuntu 22.04 — contact us for an older build    |
| GUI starts but lists no devices               | `ip link show` to confirm a `canX` interface is up                   |
