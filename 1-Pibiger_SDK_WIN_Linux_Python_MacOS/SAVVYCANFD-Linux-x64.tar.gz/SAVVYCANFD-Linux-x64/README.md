# SAVVYCANFD — Linux Customer Package

Pre-built shared libraries and Qt6 GUI for USB-CAN / CAN FD adapters on
Linux. Built against Ubuntu 22.04 (glibc 2.35) — forward-compatible with
newer Ubuntu / Debian distributions.

## Package layout

Each per-architecture tarball unwraps into a single top-level folder:

```
SAVVYCANFD-Linux-x64/                 (or SAVVYCANFD-Linux-arm64/)
├── README_LINUX.md                    this file
├── lib/libusb_can.so                  + SONAME symlinks (.so.5, .so.5.0.0)
├── bin/SAVVYCANFD                     Qt6 GUI
├── bin/can_example                    CLI quick-start
├── include/can/*.h                    public API
├── examples/basic_can.c               sample source
└── run_SAVVYCANFD.sh                  GUI launcher (sets LD_LIBRARY_PATH)
```

Pick `SAVVYCANFD-Linux-x64.tar.gz` for Intel/AMD 64-bit, or
`SAVVYCANFD-Linux-arm64.tar.gz` for Raspberry Pi / Jetson / ARM SBCs
(aarch64).

## System requirements

- Ubuntu 22.04 LTS or newer (Debian 12+, Raspberry Pi OS Bookworm)
- Qt6 runtime (only required for the `SAVVYCANFD` GUI)

```bash
sudo apt update
sudo apt install -y libqt6widgets6 libqt6gui6 libqt6core6
```

## Supported adapters

The SDK supports the common USB-CAN adapter families available on
mainstream Linux distributions. Both PCAN-USB series adapters and
standard USB-CAN / CAN FD adapters work through the same public API —
adapter selection is handled at runtime, so application code does not
change between them.

Bring up a CAN interface before running the SDK:

```bash
sudo ip link set can0 up type can bitrate 500000
# CAN FD:
sudo ip link set can0 up type can bitrate 500000 dbitrate 2000000 fd on
```

## Run the GUI

```bash
cd SAVVYCANFD-Linux-x64        # or SAVVYCANFD-Linux-arm64
./run_SAVVYCANFD.sh
```

`run_SAVVYCANFD.sh` sets `LD_LIBRARY_PATH` so the GUI finds the SDK shared
library next to itself.

## Build and link your own application

```c
// my_app.c
#include <can/usb_can_sdk.h>
#include <stdio.h>

int main(void) {
    can_sdk_init();
    can_device_info_t devs[CAN_MAX_DEVICES];
    int n = can_discover(devs, CAN_MAX_DEVICES);
    printf("Found %d CAN device(s)\n", n);
    can_sdk_shutdown();
    return 0;
}
```

```bash
gcc my_app.c \
    -Iinclude \
    -Llib -lusb_can \
    -Wl,-rpath,'$ORIGIN/lib' \
    -o my_app
```

`-Wl,-rpath,'$ORIGIN/lib'` lets the resulting binary find `libusb_can.so`
next to itself, so you can ship `my_app` + `lib/` together without
polluting `/usr/lib`.

## Public API headers (`include/can/`)

| Header             | Contents                                        |
|--------------------|-------------------------------------------------|
| `usb_can_sdk.h`    | Single-include entry point                      |
| `can_types.h`      | Types, flags, status codes, message struct      |
| `can_device.h`     | All device-control API declarations             |

## Verify the package

```bash
file lib/libusb_can.so.5.0.0
# ELF 64-bit LSB shared object, x86-64 (or ARM aarch64), dynamically linked, ...

nm -D --defined-only lib/libusb_can.so | wc -l
# Several dozen exported symbols
```

## Troubleshooting

| Symptom                                       | Fix                                                                 |
|-----------------------------------------------|----------------------------------------------------------------------|
| `Permission denied` opening device            | Run `sudo ip link set can0 up ...` (or appropriate udev rule)        |
| `error while loading shared libraries: libQt6Widgets.so.6` | `sudo apt install libqt6widgets6 libqt6gui6 libqt6core6`     |
| `error while loading shared libraries: libusb_can.so` | Use `run_SAVVYCANFD.sh`, or set `LD_LIBRARY_PATH=lib`                |
| `version 'GLIBC_2.34' not found`              | Distro is older than Ubuntu 22.04 — contact us for an older build    |
| GUI starts but lists no devices               | `ip link show` to confirm a `canX` interface is up                   |
