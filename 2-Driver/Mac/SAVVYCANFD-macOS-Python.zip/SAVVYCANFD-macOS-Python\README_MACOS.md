# SAVVYCANFD — macOS Customer Package

Build-from-source helper for macOS. Fetches and compiles the open-source
USB-CAN driver, installs the resulting dynamic library, and includes Python
quick-start examples for Classic CAN and CAN FD.

- **SDK version:** 5.0.0
- **Tested on:** macOS 12 / 13 / 14 (Apple Silicon + Intel)
- **Status:** **Frozen** as of 2026-05-14 — feature-complete standalone
  archive, not under active development. Use as-is.

> macOS does not ship with a built-in driver for USB-CAN adapters in this
> family, so the dynamic library is built locally on the customer's machine.
> No prebuilt binaries are distributed — this avoids notarisation issues and
> lets the same source serve every macOS version.

---

## 1. What's in the box

```
SAVVYCANFD-macOS-Python/
├── README_MACOS.md           this file
├── install_driver.sh         one-shot driver source download + compile + install
├── savvycanfd.py             Python helper module (open_bus, Bus, Frame)
├── requirements.txt          Python dependency pin
└── examples/
    ├── basic_can.py          Classic CAN 2.0 send + receive
    └── canfd.py              CAN FD with BRS, 64-byte payload
```

---

## 2. Prerequisites

| Requirement | Install |
|---|---|
| macOS 12 or newer | – |
| Xcode Command Line Tools | `xcode-select --install` |
| Python 3.8 – 3.12 | Ships with macOS; or `brew install python` |
| git | Ships with Xcode CLT |

`sudo` access is required (the dynamic library is placed under
`/usr/local/lib`).

---

## 3. One-time setup

```bash
# 1. Build and install the native driver (~1 min on Apple Silicon)
bash install_driver.sh

# 2. Create a virtualenv and install Python dependencies
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

`install_driver.sh` does:

1. Verify Xcode CLT, git, make, python3 are available.
2. Clone the open-source driver source into `~/savvycanfd-build/`.
3. Run `make` to produce the native dynamic library.
4. `sudo install` it into `/usr/local/lib`.
5. Remove the build tree (pass `--keep-source` to retain).

Re-run the script any time to pick up upstream fixes.

---

## 4. Run the examples

Plug in the USB-CAN adapter, then with the virtualenv active:

```bash
# Classic CAN 2.0 — 500 kbps, sends one frame, prints any received frames
python3 examples/basic_can.py

# CAN FD — 500 kbps arbitration / 2 Mbps data, BRS enabled, 64-byte payload
python3 examples/canfd.py
```

Expected first-line output:

```
[OK] Opened channel 1 @ 500 kbps
[TX] id=0x123 data=11223344
```

If no other ECU is on the bus, the listening loop simply reports zero frames
received — that's normal.

---

## 5. Use in your own application

```python
from savvycanfd import open_bus

# Classic CAN
with open_bus(channel=1, bitrate=500_000) as bus:
    bus.send_id(0x123, b"\xDE\xAD\xBE\xEF")
    msg = bus.recv(timeout=1.0)
    if msg is not None:
        print(f"0x{msg.id:X}  {msg.data.hex()}")
```

```python
from savvycanfd import open_bus

# CAN FD with BRS
with open_bus(channel=1, bitrate=500_000, fd=True, data_bitrate=2_000_000) as bus:
    bus.send_id(0x456, bytes(range(64)), fd=True, brs=True)
    for msg in bus.recv_for(seconds=1.0):
        print(msg)
```

Channels are addressed by integer index — `channel=1` for the first adapter,
`channel=2` for the second, and so on.

Supported CAN FD `data_bitrate` values: `1_000_000`, `2_000_000`,
`4_000_000`, `5_000_000` bps.

For low-level access to the underlying python-can `Bus`, `savvycanfd.Bus`
holds it as `_raw`.

---

## 6. Troubleshooting

| Symptom | Fix |
|---|---|
| `xcode-select: command not found` | Run `xcode-select --install` and accept the GUI prompt |
| `make` fails with header errors | Open Xcode once, accept the EULA, retry |
| `OSError: dlopen(libPCBUSB.dylib, …): image not found` | Re-run `install_driver.sh` — the dynamic library is missing from `/usr/local/lib` |
| `CanInitializationError: ... INITIALIZE` | Adapter not plugged in, or another process holds the device |
| Apple Silicon: Python uses Rosetta | Use an arm64 Python (`brew install python`); the dynamic library is universal |

---

## 7. Upstream source

The native driver compiled by `install_driver.sh` is fetched from the
`mac-can/PCBUSB-Library` project on GitHub. Its license file is preserved
under `~/savvycanfd-build/PCBUSB-Library/LICENSE` when you pass
`--keep-source`.

---

## 8. Customer-side build expectations

This package is **delivered as source**. The customer compiles on each
target Mac (Apple Silicon and Intel separately) — there is no universal
binary in this archive, and binaries are not shipped between machines.

A clean run on a fresh macOS 14 box (Xcode CLT installed) takes about
60 seconds end-to-end (clone → `make` → `sudo install` → first-time
`pip install`).
