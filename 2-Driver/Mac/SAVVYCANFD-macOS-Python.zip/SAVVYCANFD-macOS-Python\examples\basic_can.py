#!/usr/bin/env python3
"""SAVVYCANFD — Classic CAN 2.0 quick start on macOS.

Opens channel 1, sends one frame, prints any received frames for 2 s.
Run install_driver.sh once before this script.
"""

import os
import sys

# Make savvycanfd.py at the package root importable when running
# `python3 examples/basic_can.py` from the V5-SDK-MACOS-CUS/ folder.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from savvycanfd import open_bus  # noqa: E402


def main() -> int:
    with open_bus(channel=1, bitrate=500_000) as bus:
        print("[OK] Opened channel 1 @ 500 kbps")

        bus.send_id(0x123, b"\x11\x22\x33\x44")
        print("[TX] id=0x123 data=11223344")

        print("[RX] listening for 2 s ...")
        count = 0
        for f in bus.recv_for(seconds=2.0):
            print(f"[RX] id=0x{f.id:08X}  data={f.data.hex()}  ts={f.timestamp:.6f}")
            count += 1
        print(f"[--] {count} frame(s) received")
    return 0


if __name__ == "__main__":
    sys.exit(main())
