#!/usr/bin/env python3
"""SAVVYCANFD — CAN FD quick start on macOS.

Opens channel 1 in CAN FD mode (500 kbps arbitration / 2 Mbps data, BRS),
sends a 64-byte payload, and prints any received frames for 2 s.

The connected adapter must support CAN FD.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from savvycanfd import open_bus  # noqa: E402


def main() -> int:
    with open_bus(channel=1, bitrate=500_000, fd=True, data_bitrate=2_000_000) as bus:
        print("[OK] Opened channel 1 (FD): nominal=500 kbps  data=2000 kbps")

        payload = bytes(range(64))
        bus.send_id(0x456, payload, fd=True, brs=True)
        print(f"[TX] id=0x456  dlc={len(payload)}  (FD+BRS)")

        print("[RX] listening for 2 s ...")
        count = 0
        for f in bus.recv_for(seconds=2.0):
            flags = []
            if f.is_fd:  flags.append("FD")
            if f.is_brs: flags.append("BRS")
            if f.is_esi: flags.append("ESI")
            tag = "(" + ",".join(flags) + ")" if flags else ""
            print(f"[RX] id=0x{f.id:08X}  dlc={len(f.data):2d} {tag}  data={f.data.hex()}")
            count += 1
        print(f"[--] {count} frame(s) received")
    return 0


if __name__ == "__main__":
    sys.exit(main())
