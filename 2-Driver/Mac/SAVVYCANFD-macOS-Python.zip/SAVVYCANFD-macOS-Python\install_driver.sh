#!/usr/bin/env bash
# SAVVYCANFD — macOS USB-CAN driver installer.
#
# Downloads the open-source CAN driver from GitHub, compiles it natively,
# installs the resulting dylib into /usr/local/lib so that the bundled
# Python examples can locate it via dlopen at runtime.
#
# Tested on macOS 12+ (Apple Silicon and Intel).
#
# Usage:
#   bash install_driver.sh                # download + build + install
#   bash install_driver.sh --keep-source  # leave the build tree under ~/savvycanfd-build/
#
# After running, smoke-test with:
#   python3 examples/basic_can.py
#
set -euo pipefail

# --- configuration ---------------------------------------------------------
DRIVER_REPO_URL="https://github.com/mac-can/PCBUSB-Library.git"
DRIVER_DYLIB="libPCBUSB.dylib"
INSTALL_PREFIX="/usr/local/lib"
BUILD_ROOT="${HOME}/savvycanfd-build"
KEEP_SOURCE=0

if [ "${1:-}" = "--keep-source" ]; then
    KEEP_SOURCE=1
fi

# --- prerequisites ---------------------------------------------------------
echo "==> Checking prerequisites"

if ! xcode-select -p >/dev/null 2>&1; then
    echo "[ERROR] Xcode Command Line Tools not installed."
    echo "        Install with:  xcode-select --install"
    exit 1
fi

for tool in git make python3 sudo; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        echo "[ERROR] Missing tool: $tool"
        exit 1
    fi
done
echo "    OK — Xcode CLT, git, make, python3 present."

ARCH="$(uname -m)"
echo "    Host architecture: $ARCH"

# --- fetch source ----------------------------------------------------------
mkdir -p "$BUILD_ROOT"
cd "$BUILD_ROOT"

if [ -d PCBUSB-Library/.git ]; then
    echo "==> Updating existing source tree at $BUILD_ROOT/PCBUSB-Library"
    git -C PCBUSB-Library fetch --depth 1 origin
    git -C PCBUSB-Library reset --hard origin/HEAD
else
    echo "==> Cloning driver source from $DRIVER_REPO_URL"
    git clone --depth 1 "$DRIVER_REPO_URL"
fi

# --- compile ---------------------------------------------------------------
cd PCBUSB-Library

# The repo ships a top-level Makefile that builds a universal dylib.
# If absent (layout change upstream), fall back to a Sources/ subdir.
if [ -f Makefile ]; then
    BUILD_DIR="$(pwd)"
elif [ -f Sources/Makefile ]; then
    BUILD_DIR="$(pwd)/Sources"
else
    echo "[ERROR] No Makefile found in repository — upstream layout has changed."
    echo "        Inspect $BUILD_ROOT/PCBUSB-Library and adjust install_driver.sh."
    exit 1
fi

echo "==> Compiling in $BUILD_DIR"
( cd "$BUILD_DIR" && make )

# Locate the produced dylib. Upstream places it under build/, Binaries/,
# or the build root depending on Makefile target.
DYLIB_PATH="$(find "$BUILD_DIR" -name "$DRIVER_DYLIB" -type f -print -quit || true)"
if [ -z "$DYLIB_PATH" ]; then
    echo "[ERROR] Compilation finished but $DRIVER_DYLIB not found."
    echo "        Check the make output above; the upstream Makefile may have"
    echo "        renamed the artifact."
    exit 1
fi
echo "    Built: $DYLIB_PATH"

# --- install ---------------------------------------------------------------
echo "==> Installing to $INSTALL_PREFIX (requires sudo)"
sudo install -d "$INSTALL_PREFIX"
sudo install -m 0755 "$DYLIB_PATH" "$INSTALL_PREFIX/$DRIVER_DYLIB"

# Refresh the dyld cache hint (best-effort; not fatal if it errors).
if command -v update_dyld_shared_cache >/dev/null 2>&1; then
    sudo update_dyld_shared_cache 2>/dev/null || true
fi

# --- verify ----------------------------------------------------------------
echo "==> Verifying install"
ls -l "$INSTALL_PREFIX/$DRIVER_DYLIB"
file "$INSTALL_PREFIX/$DRIVER_DYLIB"

# --- cleanup ---------------------------------------------------------------
if [ "$KEEP_SOURCE" -eq 0 ]; then
    echo "==> Removing build tree (pass --keep-source to retain)"
    rm -rf "$BUILD_ROOT/PCBUSB-Library"
fi

echo
echo "=== Driver install complete ==="
echo "Next:"
echo "  python3 -m venv .venv && source .venv/bin/activate"
echo "  pip install -r python/requirements.txt"
echo "  python3 examples/basic_can.py"
