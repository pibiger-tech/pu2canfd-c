"""SAVVYCANFD — macOS helper module.

Thin wrapper over python-can that hides the underlying interface string
and provides integer channel addressing.

Example::

    from savvycanfd import open_bus

    with open_bus(channel=1, bitrate=500_000) as bus:
        bus.send_id(0x123, b'\\x11\\x22\\x33\\x44')
        for msg in bus.recv_for(seconds=1.0):
            print(msg)
"""

from __future__ import annotations

import contextlib
import time
from dataclasses import dataclass
from typing import Iterator, Optional

import can

# python-can channel-name template for this adapter family on macOS.
# Kept internal — customer code addresses channels by integer index.
_CHANNEL_TEMPLATE = "PCAN_USBBUS{n}"
_DRIVER_INTERFACE = "pcan"

# Reasonable bit-timing presets for an 80 MHz clock; cover the common
# CAN FD data-phase rates without exposing brp/tseg knobs to callers.
_FD_TIMING_NOMINAL = dict(f_clock_mhz=80,
                          nom_brp=10, nom_tseg1=12, nom_tseg2=3, nom_sjw=1)
_FD_TIMING_DATA = {
    1_000_000: dict(data_brp=4,  data_tseg1=15, data_tseg2=4, data_sjw=1),
    2_000_000: dict(data_brp=2,  data_tseg1=15, data_tseg2=4, data_sjw=1),
    4_000_000: dict(data_brp=1,  data_tseg1=15, data_tseg2=4, data_sjw=1),
    5_000_000: dict(data_brp=1,  data_tseg1=11, data_tseg2=4, data_sjw=1),
}


@dataclass
class Frame:
    """Decoded received frame."""
    id: int
    data: bytes
    timestamp: float
    is_extended: bool = False
    is_fd: bool = False
    is_brs: bool = False
    is_esi: bool = False

    @classmethod
    def from_can(cls, m: can.Message) -> "Frame":
        return cls(
            id=m.arbitration_id,
            data=bytes(m.data),
            timestamp=m.timestamp,
            is_extended=bool(m.is_extended_id),
            is_fd=bool(m.is_fd),
            is_brs=bool(m.bitrate_switch),
            is_esi=bool(m.error_state_indicator),
        )


class Bus:
    """Open USB-CAN channel. Use :func:`open_bus` to create one."""

    def __init__(self, raw: can.BusABC):
        self._raw = raw

    # --- send -------------------------------------------------------------
    def send_id(self, can_id: int, data: bytes,
                *, extended: bool = False,
                fd: bool = False, brs: bool = False) -> None:
        msg = can.Message(arbitration_id=can_id,
                          data=data,
                          is_extended_id=extended,
                          is_fd=fd,
                          bitrate_switch=brs)
        self._raw.send(msg)

    # --- receive ----------------------------------------------------------
    def recv(self, timeout: float = 1.0) -> Optional[Frame]:
        m = self._raw.recv(timeout=timeout)
        return None if m is None else Frame.from_can(m)

    def recv_for(self, seconds: float, *, poll: float = 0.2) -> Iterator[Frame]:
        deadline = time.time() + seconds
        while time.time() < deadline:
            m = self._raw.recv(timeout=min(poll, deadline - time.time()))
            if m is not None:
                yield Frame.from_can(m)

    # --- lifecycle --------------------------------------------------------
    def close(self) -> None:
        self._raw.shutdown()

    def __enter__(self) -> "Bus":
        return self

    def __exit__(self, *exc) -> None:
        self.close()


def open_bus(channel: int = 1,
             *,
             bitrate: int = 500_000,
             fd: bool = False,
             data_bitrate: Optional[int] = None) -> Bus:
    """Open a USB-CAN channel by integer index.

    Args:
        channel: 1-based channel index (1, 2, …).
        bitrate: Arbitration-phase bitrate in bits/sec. For Classic CAN this
            is the only bitrate. Default 500 kbps.
        fd: Set True for CAN FD. ``data_bitrate`` must then also be supplied.
        data_bitrate: CAN FD data-phase bitrate in bits/sec.
            Supported: 1_000_000, 2_000_000, 4_000_000, 5_000_000.

    Returns:
        A :class:`Bus` ready for ``send_id`` and ``recv``.
    """
    channel_name = _CHANNEL_TEMPLATE.format(n=channel)

    if not fd:
        raw = can.Bus(interface=_DRIVER_INTERFACE,
                      channel=channel_name,
                      bitrate=bitrate)
        return Bus(raw)

    if data_bitrate is None:
        raise ValueError("CAN FD requires data_bitrate")
    if data_bitrate not in _FD_TIMING_DATA:
        raise ValueError(
            f"Unsupported FD data_bitrate {data_bitrate}; "
            f"choose from {sorted(_FD_TIMING_DATA)}")

    raw = can.Bus(interface=_DRIVER_INTERFACE,
                  channel=channel_name,
                  fd=True,
                  **_FD_TIMING_NOMINAL,
                  **_FD_TIMING_DATA[data_bitrate])
    return Bus(raw)


@contextlib.contextmanager
def opened(*args, **kwargs):
    """Context-manager shorthand: ``with opened(channel=1) as bus: …``."""
    bus = open_bus(*args, **kwargs)
    try:
        yield bus
    finally:
        bus.close()
