# PIBIGER USB-CAN SDK 开发指南

本文件描述如何使用 PIBIGER USB-CAN SDK 开发自己的 CAN 应用。

---

## 1. 环境搭建

### 1.1 开发工具

推荐组合：
- **IDE/编译器**：Visual Studio 2019 或 2022（Community 即可）
- **构建系统**：CMake 3.16 或更新
- **硬件**：PCAN-USB 或 PCAN-USB FD
- **驱动**：PCAN-Basic API (从 PEAK 官网下载安装)

### 1.2 验证环境

```cmd
cl              # 应显示 MSVC 版本
cmake --version # 应显示 CMake 3.16+
```

然后连接 PCAN-USB 设备，运行 `bin\can_example.exe` 验证硬件工作正常。

---

## 2. 项目模板

### 2.1 最小目录结构

```
my_project/
├── CMakeLists.txt
├── main.c
└── sdk/                 (复制 V5-SDK-DLL-CUS 到此)
    ├── bin/usb_can.dll
    ├── lib/usb_can.lib
    └── include/can/...
```

### 2.2 CMakeLists.txt 模板

```cmake
cmake_minimum_required(VERSION 3.16)
project(my_can_app LANGUAGES C)

set(SDK_DIR ${CMAKE_SOURCE_DIR}/sdk)

add_executable(my_app main.c)

target_include_directories(my_app PRIVATE ${SDK_DIR}/include)
target_link_libraries(my_app PRIVATE ${SDK_DIR}/lib/usb_can.lib)

# Deploy usb_can.dll next to the exe
add_custom_command(TARGET my_app POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_if_different
        ${SDK_DIR}/bin/usb_can.dll $<TARGET_FILE_DIR:my_app>)
```

---

## 3. 典型应用模式

### 3.1 周期发送 + 接收线程

```c
#include "can/usb_can_sdk.h"
#include <windows.h>
#include <stdio.h>

static volatile int g_running = 1;

DWORD WINAPI rx_thread(LPVOID arg) {
    can_handle_t h = (can_handle_t)arg;
    can_msg_t buf[64];
    while (g_running) {
        int n = can_receive(h, buf, 64, 100); /* 100ms 超时 */
        for (int i = 0; i < n; i++) {
            printf("RX 0x%X ", buf[i].id);
            for (int j = 0; j < buf[i].dlc; j++)
                printf("%02X ", buf[i].data[j]);
            printf("\n");
        }
    }
    return 0;
}

int main(void) {
    can_sdk_init();

    can_device_info_t dev;
    if (can_discover(&dev, 1) <= 0) { printf("no device\n"); return 1; }

    can_handle_t h;
    can_open(&h, dev.index);

    can_config_t cfg = { 0 };
    cfg.bitrate = 500000;
    can_configure(h, &cfg);
    can_start(h);

    HANDLE th = CreateThread(NULL, 0, rx_thread, h, 0, NULL);

    /* 周期发送 TX */
    can_msg_t tx = { 0 };
    tx.id  = 0x123;
    tx.dlc = 8;
    while (g_running) {
        for (int i = 0; i < 8; i++) tx.data[i]++;
        can_send(h, &tx);
        Sleep(100);
    }

    WaitForSingleObject(th, INFINITE);

    can_stop(h);
    can_close(h);
    can_sdk_shutdown();
    return 0;
}
```

### 3.2 总线错误自恢复

```c
void service(can_handle_t h) {
    can_stats_t s;
    can_get_stats(h, &s);
    if (s.bus_state == CAN_STATE_BUS_OFF) {
        fprintf(stderr, "Bus-off detected, resetting...\n");
        can_reset(h);
        can_start(h);
    }
}
```

### 3.3 过滤应用层 ID

本 SDK 不内置硬件滤波。推荐在应用层过滤：

```c
for (int i = 0; i < n; i++) {
    if (buf[i].id == MY_TARGET_ID) handle_frame(&buf[i]);
}
```

如需硬件过滤可联系 PIBIGER 扩展支持。

---

## 4. 错误处理建议

1. **所有 API 都返回状态码**（`can_status_t` 或负数），务必检查。
2. 在发送/接收的热路径，使用 `can_status_str()` 打印友好信息。
3. `CAN_ERR_TIMEOUT` 不等于失败 —— 表示没有新消息到达。
4. `CAN_ERR_BUS_OFF` 需要调用 `can_reset()` 后再 `can_start()`。

```c
can_status_t rc = can_send(h, &tx);
switch (rc) {
    case CAN_OK:              break;
    case CAN_ERR_BUS_OFF:     handle_bus_off(h);      break;
    case CAN_ERR_BUFFER_FULL: Sleep(1);               break;
    default: fprintf(stderr, "send: %s\n", can_status_str(rc));
}
```

---

## 5. 性能调优

| 场景            | 建议                                                     |
|-----------------|----------------------------------------------------------|
| 高频接收        | 单线程调用 `can_receive(timeout_ms=1..10)`               |
| 高频发送        | 不要在循环中 `Sleep(0)` 或忙等待，尊重 `BUFFER_FULL`     |
| 精确时间戳      | 使用 `can_msg_t.timestamp_us`（微秒级）                  |
| CAN FD 大帧     | `can_configure()` 时开启 `canfd_enabled = 1`             |

---

## 6. 跨语言调用

### 6.1 C++（直接）

```cpp
extern "C" {
#include "can/usb_can_sdk.h"
}
```

### 6.2 C# (P/Invoke)

```csharp
[DllImport("usb_can.dll")] static extern int can_sdk_init();
[DllImport("usb_can.dll")] static extern int can_open(out IntPtr h, int idx);
[DllImport("usb_can.dll")] static extern int can_send(IntPtr h, ref CanMsg m);
```

完整 C# 绑定请联系 PIBIGER 获取示例。

### 6.3 Python (ctypes)

```python
import ctypes
sdk = ctypes.CDLL("./usb_can.dll")
sdk.can_sdk_init()
h = ctypes.c_void_p()
sdk.can_open(ctypes.byref(h), 0)
```

---

## 7. 调试技巧

1. **确认 DLL 正确加载**：
   - 运行 `depends.exe` 或 `dumpbin /dependents my_app.exe`，确保看到 `usb_can.dll` 和 `PCANBasic.dll`。
2. **PCANBasic.dll 找不到**：
   - 把它放到 exe 同目录；或确认 PEAK 驱动正确安装。
3. **消息收不到**：
   - 用本 SDK 附带的 `canviewer` 先验证硬件，排除物理层问题。
   - 检查波特率、采样点、总线终端电阻。
4. **时间戳跳变**：
   - 当前实现使用系统时钟（`std::chrono::system_clock`）。若需单调时钟，可联系 PIBIGER 定制。

---

## 8. 常见问题 (FAQ)

**Q：是否支持 Linux？**
A：5.0 仅支持 Windows。Linux 版本在规划中。

**Q：支持多少个并发设备？**
A：取决于 PCAN 驱动，典型上限 8-16 个 PCAN-USB。

**Q：最大收发吞吐？**
A：取决于设备型号。经典 CAN 1Mbps 约 8000 帧/秒；CAN FD 64 字节帧约 15000 帧/秒。

**Q：是否支持 J1939 / CANopen / UDS？**
A：SDK 只提供原始帧收发。上层协议栈需自行实现或联系 PIBIGER 获取扩展包。

**Q：能否和 GUI (canviewer) 同时打开同一设备？**
A：不能。PCAN 设备同一时刻只能被一个进程占用。

---

## 9. 获取帮助

- 示例程序：`example/basic_can.c`
- API 参考：`README.md`
- 技术支持：联系 PIBIGER
