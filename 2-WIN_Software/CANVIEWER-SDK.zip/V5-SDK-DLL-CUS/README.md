# PIBIGER USB-CAN SDK v5.0

PIBIGER USB-CAN SDK 提供简单的 C 语言 API，用于通过 PCAN USB 设备进行 CAN / CAN FD 总线通信。本 SDK 封装了底层 PCAN-Basic API，并以跨编译器、跨语言友好的纯 C 接口发布。

---

## 目录结构

```
V5-SDK-DLL-CUS/
├── README.md                本文件
├── CMakeLists.txt           构建脚本(用于构建 example)
├── bin/
│   ├── usb_can.dll          SDK 动态链接库
│   └── can_example.exe      示例程序
├── lib/
│   └── usb_can.lib          导入库(链接用)
├── include/can/
│   ├── usb_can_sdk.h        主头文件（只需 include 此文件）
│   ├── can_types.h          类型定义、错误码、消息结构
│   └── can_device.h         设备控制 API
└── example/
    └── basic_can.c          完整示例代码
```

---

## 系统要求

- Windows 10 / 11 (x64)
- MSVC 2019 或 2022
- CMake 3.16+（可选）
- PCAN USB 设备（PEAK System PCAN-USB / PCAN-USB FD）
- PCANBasic.dll（PEAK 官方驱动，需单独下载安装）

---

## 运行时依赖

将以下 DLL 放在你的可执行文件同目录：
- `usb_can.dll` — 本 SDK 库
- `PCANBasic.dll` — PCAN 驱动（从 PEAK System 官网下载）

---

## 快速开始

### 1. 在你的代码中引用

```c
#include "can/usb_can_sdk.h"
```

### 2. 基本工作流程

```
can_sdk_init()        →  初始化 SDK
can_discover()        →  扫描可用 CAN 设备
can_open()            →  打开指定设备
can_configure()       →  配置波特率等参数
can_start()           →  启动 CAN 通信
can_send() /          →  发送 / 接收 CAN 帧
  can_receive()
can_stop()            →  停止通信
can_close()           →  关闭设备
can_sdk_shutdown()    →  关闭 SDK
```

### 3. 最小代码片段

```c
#include "can/usb_can_sdk.h"
#include <stdio.h>

int main(void) {
    can_sdk_init();

    can_device_info_t devs[CAN_MAX_DEVICES];
    int n = can_discover(devs, CAN_MAX_DEVICES);
    if (n <= 0) { printf("No device\n"); return 1; }

    can_handle_t h;
    can_open(&h, devs[0].index);

    can_config_t cfg = { 0 };
    cfg.bitrate = 500000;
    can_configure(h, &cfg);
    can_start(h);

    can_msg_t tx = { 0 };
    tx.id  = 0x123;
    tx.dlc = 8;
    for (int i = 0; i < 8; i++) tx.data[i] = i;
    can_send(h, &tx);

    can_msg_t rx[16];
    int cnt = can_receive(h, rx, 16, 1000);
    for (int i = 0; i < cnt; i++)
        printf("RX ID=0x%X DLC=%u\n", rx[i].id, rx[i].dlc);

    can_stop(h);
    can_close(h);
    can_sdk_shutdown();
    return 0;
}
```

---

## 编译方法

### 方法 1：MSVC 命令行

```cmd
cl your_app.c /I path\to\include /link path\to\lib\usb_can.lib
```

### 方法 2：CMake

```cmake
cmake_minimum_required(VERSION 3.16)
project(my_can_app LANGUAGES C)

add_executable(my_app main.c)
target_include_directories(my_app PRIVATE ${SDK_DIR}/include)
target_link_libraries(my_app ${SDK_DIR}/lib/usb_can.lib)

# Copy runtime DLLs next to the executable
add_custom_command(TARGET my_app POST_BUILD
    COMMAND ${CMAKE_COMMAND} -E copy_if_different
        ${SDK_DIR}/bin/usb_can.dll $<TARGET_FILE_DIR:my_app>)
```

### 方法 3：构建并运行示例

```cmd
cd V5-SDK-DLL-CUS
cmake -S . -B build -A x64
cmake --build build --config Release
build\Release\can_example.exe
```

---

## API 参考

### SDK 生命周期

| 函数                    | 说明                         |
|-------------------------|------------------------------|
| `can_sdk_init()`        | 初始化 SDK（启动时调用一次） |
| `can_sdk_shutdown()`    | 关闭 SDK（退出时调用一次）   |

### 设备发现与管理

| 函数                                  | 说明                    |
|---------------------------------------|-------------------------|
| `can_discover(devices, max_count)`    | 扫描设备，返回数量      |
| `can_open(&handle, device_index)`     | 按索引打开设备          |
| `can_close(handle)`                   | 关闭设备                |
| `can_get_name(handle)`                | 获取设备名称            |
| `can_get_version(handle)`             | 获取 SDK 版本           |
| `can_get_capabilities(handle)`        | 获取设备能力（bitmask） |

### 配置

| 函数                                | 说明                 |
|-------------------------------------|----------------------|
| `can_configure(handle, &config)`    | 配置波特率 / CAN FD  |
| `can_get_config(handle, &config)`   | 读取当前配置         |

### 总线控制

| 函数                       | 说明                          |
|----------------------------|-------------------------------|
| `can_start(handle)`        | 启动 CAN 通信（初始化硬件）   |
| `can_stop(handle)`         | 停止 CAN 通信                 |
| `can_reset(handle)`        | 复位总线（清除错误）          |
| `can_get_state(handle)`    | 获取总线状态（CAN_STATE_*）   |

### 消息收发

| 函数                                                | 说明                      |
|-----------------------------------------------------|---------------------------|
| `can_send(handle, &msg)`                            | 发送一帧                  |
| `can_receive(handle, msgs, max_count, timeout_ms)`  | 接收一组帧（0=非阻塞）    |

### 统计与诊断

| 函数                               | 说明                       |
|------------------------------------|----------------------------|
| `can_get_stats(handle, &stats)`    | 获取收发统计               |
| `can_reset_stats(handle)`          | 重置统计计数器             |
| `can_status_str(status)`           | 错误码转字符串（便于打印） |

---

## 数据结构

### can_msg_t — CAN 消息

```c
typedef struct {
    uint32_t id;            /* CAN ID (11-bit 或 29-bit) */
    uint8_t  dlc;           /* 数据长度 (0-8 或 CAN FD 0-64) */
    uint8_t  flags;         /* 标志位 (CAN_FLAG_*) */
    uint8_t  reserved[2];
    uint8_t  data[64];      /* 数据 */
    uint64_t timestamp_us;  /* 微秒级时间戳 */
} can_msg_t;
```

### can_config_t — 配置

```c
typedef struct {
    uint32_t bitrate;            /* 仲裁段波特率 (如 500000) */
    uint32_t sample_point;       /* 采样点 (1000=100%, 875=87.5%) */
    uint8_t  canfd_enabled;      /* 0=经典CAN, 1=CAN FD */
    uint32_t data_bitrate;       /* FD 数据段波特率 */
    uint32_t data_sample_point;  /* FD 数据段采样点 */
} can_config_t;
```

### can_device_info_t — 设备信息

```c
typedef struct {
    int      index;
    char     name[CAN_MAX_NAME_LEN];
    char     description[CAN_MAX_NAME_LEN];
    char     driver[CAN_MAX_NAME_LEN];
    uint32_t capabilities;
} can_device_info_t;
```

### can_stats_t — 统计

```c
typedef struct {
    uint64_t rx_frames;
    uint64_t tx_frames;
    uint32_t rx_errors;
    uint32_t tx_errors;
    uint32_t rx_overruns;
    uint32_t tx_dropped;
    uint32_t bus_state;    /* CAN_STATE_* */
} can_stats_t;
```

---

## 常量速查

### 帧标志位

| 常量                   | 值   | 说明                    |
|------------------------|------|-------------------------|
| `CAN_FLAG_EXTENDED`    | 0x01 | 29-bit 扩展帧           |
| `CAN_FLAG_RTR`         | 0x02 | 远程帧                  |
| `CAN_FLAG_FD`          | 0x04 | CAN FD 帧               |
| `CAN_FLAG_BRS`         | 0x08 | 位率切换 (FD only)      |
| `CAN_FLAG_ERROR`       | 0x10 | 错误帧                  |

### 错误码

| 常量                       | 值   | 说明           |
|----------------------------|------|----------------|
| `CAN_OK`                   |  0   | 成功           |
| `CAN_ERR_INVALID_PARAM`    | -1   | 参数无效       |
| `CAN_ERR_NO_DEVICE`        | -2   | 未找到设备     |
| `CAN_ERR_OPEN_FAILED`      | -3   | 打开失败       |
| `CAN_ERR_NOT_OPEN`         | -4   | 设备未打开     |
| `CAN_ERR_SEND_FAILED`      | -5   | 发送失败       |
| `CAN_ERR_TIMEOUT`          | -6   | 超时           |
| `CAN_ERR_BUS_OFF`          | -7   | 总线关闭       |
| `CAN_ERR_BUFFER_FULL`      | -8   | 队列已满       |
| `CAN_ERR_NOT_SUPPORTED`    | -9   | 不支持         |
| `CAN_ERR_INTERNAL`         | -10  | 内部错误       |

### 总线状态

| 常量                 | 值 | 说明                          |
|----------------------|----|-------------------------------|
| `CAN_STATE_OK`       | 0  | 错误激活 (Error Active)       |
| `CAN_STATE_WARNING`  | 1  | 错误警告 (Error Warning)      |
| `CAN_STATE_PASSIVE`  | 2  | 错误被动 (Error Passive)      |
| `CAN_STATE_BUS_OFF`  | 3  | 总线关闭                      |
| `CAN_STATE_STOPPED`  | 4  | 已停止                        |
| `CAN_STATE_UNKNOWN`  | 5  | 未知                          |

### 设备能力

| 常量                   | 值   | 说明           |
|------------------------|------|----------------|
| `CAN_CAP_CANFD`        | 0x01 | 支持 CAN FD    |
| `CAN_CAP_LISTEN_ONLY`  | 0x02 | 仅监听模式     |
| `CAN_CAP_ONE_SHOT`     | 0x08 | 单次发送       |
| `CAN_CAP_AUTO_RESTART` | 0x10 | 总线关闭自恢复 |

---

## 常见开发任务

### 1. 只发送一帧

```c
can_msg_t msg = { 0 };
msg.id  = 0x100;
msg.dlc = 2;
msg.data[0] = 0xAA; msg.data[1] = 0xBB;
if (can_send(h, &msg) == CAN_OK) printf("sent\n");
```

### 2. 发送扩展帧 (29-bit)

```c
can_msg_t msg = { 0 };
msg.id    = 0x18FF50E0;
msg.dlc   = 8;
msg.flags = CAN_FLAG_EXTENDED;
can_send(h, &msg);
```

### 3. 发送 CAN FD 帧（位率切换 64 字节）

```c
can_config_t cfg = { 0 };
cfg.bitrate       = 500000;
cfg.canfd_enabled = 1;
cfg.data_bitrate  = 2000000;
can_configure(h, &cfg);
can_start(h);

can_msg_t fd = { 0 };
fd.id    = 0x200;
fd.dlc   = 64;
fd.flags = CAN_FLAG_FD | CAN_FLAG_BRS;
can_send(h, &fd);
```

### 4. 阻塞接收（最多等 100ms）

```c
can_msg_t buf[32];
int n = can_receive(h, buf, 32, 100);
for (int i = 0; i < n; i++) {
    printf("[%llu us] 0x%X DLC=%u\n",
           (unsigned long long)buf[i].timestamp_us,
           buf[i].id, buf[i].dlc);
}
```

### 5. 监控总线状态

```c
if (can_get_state(h) == CAN_STATE_BUS_OFF) {
    can_reset(h);   /* 清除错误并重新加入总线 */
}
```

### 6. 错误码打印

```c
can_status_t s = can_configure(h, &cfg);
if (s != CAN_OK) fprintf(stderr, "configure: %s\n", can_status_str(s));
```

---

## 部署到最终产品

1. 将以下文件随你的应用一起分发：
   - `usb_can.dll`
   - `PCANBasic.dll`（PEAK 官方，不得捆绑，需用户单独安装或指引下载）
2. 你的 .exe、`usb_can.dll`、`PCANBasic.dll` 应当放在同一目录。
3. 目标机器需安装 **PEAK PCAN-USB 驱动**。

---

## 线程模型

- 所有 API 调用均是 **同步** 的。
- 一个 `can_handle_t` 同一时刻只应由一个线程使用。
- 可以为不同设备各开一个线程；每个线程持有自己的 handle。
- `can_receive(... timeout_ms=0)` 为非阻塞；`>0` 为阻塞直到有帧或超时。

---

## 支持的设备

- PCAN-USB / PCAN-USB FD (PEAK System)
- 后续版本将支持 WinUSB / LibUSB 自定义 CAN 设备

---

## 版本历史

| 版本 | 日期       | 说明                                                    |
|------|------------|---------------------------------------------------------|
| 5.0  | 2026-04    | 重构为独立 DLL；微秒级时间戳；品牌重命名为 PIBIGER      |
| 3.0  | 2026-04    | 第一版稳定 API                                          |

---

## 技术支持

- 问题反馈：联系 PIBIGER 技术支持
- 示例代码：`example/basic_can.c`
- GUI 工具：`canviewer`（可随 SDK 一起提供，作为参考实现）
